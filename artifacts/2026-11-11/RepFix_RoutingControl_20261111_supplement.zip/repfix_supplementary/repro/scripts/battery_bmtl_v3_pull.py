"""BMTL: Battery Multi-Task Learning — gradient toxicity + STF repair
specialized for SOH & RUL prediction.  Built on the RepFix theory.

 Architecture
   per-cycle window  x:(B,T,D_in)
     -> TSMixer encoder (keep T)              (B,T,d)
     -> GatedDeltaNet encoder (keep T)        (B,T,d)
     -> mean-pool over time  z:(B,d)
   primary heads : SOH MSE head, RUL MAE head     (drive the encoder)
   toxic aux heads: AE reconstruction head, MDN RUL-distribution head
                   (constant attractors; their grads collapse the encoder)

 Configs
   joint    : no isolation, no weighting            -> expected collapse
   joint_w  : no isolation, tri-weighting           -> weights help but collapse persists
   stf0     : STF-0 (detach aux) isolation          -> repaired, no weighting
   stf0_w   : STF-0 + tri-weighting  (ours, full)   -> best

 Tri-weighting (MTG-style, multiplicative)
   w_i = w_rate(rate_i) * w_temp(temp_i) * w_degrad(|dSOH|_i)
   up-weighs fast-charging / extreme-temp / rapid-degradation windows.

 Run (after battery_parsed/<ds>_cycles.json exists):
   python battery_bmtl.py --dataset CALCE --out results/battery_bmtl_CALCE.json
"""
from __future__ import annotations
import argparse, json, math, os, random, sys, time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from cross_domain_mtl import set_seed, enable_max_perf


# =============================================================================
#  TSMixer block/encoder (ICDM2023) -- feature + temporal mixing, keeps T
# =============================================================================
class TSMixerBlock(nn.Module):
    def __init__(self, d: int, max_ts: int, dropout=0.05):
        super().__init__()
        self.norm_f = nn.LayerNorm(d)
        self.f1 = nn.Linear(d, 4*d); self.f2 = nn.Linear(4*d, d)
        self.norm_t = nn.LayerNorm(d)
        # time mixing: after feature mixing, apply Linear along time axis
        # since all sequences already padded/cut to max_ts, fixed shape.
        self.t1 = nn.Linear(max_ts, 4*max_ts); self.t2 = nn.Linear(4*max_ts, max_ts)
        self.drop = dropout
        self.max_ts = max_ts

    def forward(self, x):                     # x:(B,T,d)
        r = x; x = self.norm_f(x)
        x = F.gelu(self.f1(x)); x = F.dropout(x, self.drop, training=self.training)
        x = r + self.f2(x)
        r = x; x = self.norm_t(x)
        xt = x.transpose(1, 2)                                 # (B,d,T)
        h = F.gelu(self.t1(xt)); h = F.dropout(h, self.drop, training=self.training)
        x = r + self.t2(h).transpose(1, 2)                     # back to (B,T,d)
        return x


class TSMixerEncoder(nn.Module):
    def __init__(self, d_in, d, max_ts, n_layer=2, dropout=0.05):
        super().__init__()
        self.proj = nn.Linear(d_in, d)
        self.blocks = nn.ModuleList([TSMixerBlock(d, max_ts, dropout) for _ in range(n_layer)])
        self.norm = nn.LayerNorm(d)

    def forward(self, x):                     # (B,T,d_in)->(B,T,d)
        x = F.silu(self.proj(x))
        for b in self.blocks:
            x = b(x)
        return self.norm(x)


# =============================================================================
#  GatedDeltaNet block/encoder -- gated MLP with depthwise channel mixing, keeps T
# =============================================================================
class GatedDeltaBlock(nn.Module):
    def __init__(self, d, kernel=3, expansion=4, dropout=0.05):
        super().__init__()
        self.dw = nn.Conv1d(d, d, kernel, groups=d, padding=kernel//2)
        self.norm = nn.LayerNorm(d)
        self.a = nn.Linear(d, expansion*d); self.b = nn.Linear(expansion*d, d)
        self.g = nn.Linear(d, expansion*d)
        self.drop = dropout

    def forward(self, x):                     # (B,T,d)
        r = x
        x = F.silu(self.dw(x.transpose(1, 2)).transpose(1, 2))
        h = F.gelu(self.a(x)) * F.silu(self.g(x))
        h = F.dropout(h, self.drop, training=self.training)
        return r + self.norm(self.b(h) + x)


class GatedDeltaEncoder(nn.Module):
    def __init__(self, d_in, d, n_layer=2, dropout=0.05):
        super().__init__()
        self.proj = nn.Linear(d_in, d)
        self.blocks = nn.ModuleList([GatedDeltaBlock(d, dropout=dropout) for _ in range(n_layer)])
        self.norm = nn.LayerNorm(d)

    def forward(self, x):                     # (B,T,d_in)->(B,T,d)
        x = self.proj(x)
        for b in self.blocks:
            x = b(x)
        return self.norm(x)


# =============================================================================
#  Toxic auxiliary heads (constant attractors)
# =============================================================================
class AEToxicHead(nn.Module):
    def __init__(self, d_emb, d_in, n_ts):
        super().__init__()
        self.dec = nn.Sequential(nn.Linear(d_emb, 2*d_emb), nn.ReLU(),
                                 nn.Linear(2*d_emb, 2*d_emb), nn.ReLU(),
                                 nn.Linear(2*d_emb, n_ts*d_in))
        self.n_ts, self.d_in = n_ts, d_in

    def forward(self, z):                      # (B,d_emb)->(B,T,D_in)
        return self.dec(z).reshape(z.shape[0], self.n_ts, self.d_in)


class MDNToxicHead(nn.Module):
    def __init__(self, d_emb, k=3):
        super().__init__()
        self.pi = nn.Linear(d_emb, k); self.mu = nn.Linear(d_emb, k)
        self.sig = nn.Linear(d_emb, k)

    def forward(self, z):
        return (F.softmax(self.pi(z), -1), self.mu(z), F.softplus(self.sig(z)) + 1e-3)

    @staticmethod
    def nll(pi, mu, sig, y):
        y = y.unsqueeze(-1)
        comp = pi / (sig * math.sqrt(2*math.pi)) * torch.exp(-0.5*((y-mu)/sig).pow(2))
        return -torch.log(comp.sum(-1).clamp_min(1e-10))


# =============================================================================
#  Full model
# =============================================================================
class BMTL(nn.Module):
    def __init__(self, d_in, d=128, n_ts=128, use_tsmixer=True, use_gatedelta=True, k_mdn=3):
        super().__init__()
        self.use_t, self.use_g, self.n_ts, self.d_in = use_tsmixer, use_gatedelta, n_ts, d_in
        self.proj = nn.Linear(d_in, d)
        self.ts = TSMixerEncoder(d, d, n_ts) if use_tsmixer else None
        self.gd = GatedDeltaEncoder(d, d) if use_gatedelta else None
        self.norm = nn.LayerNorm(d)
        self.head_soh = nn.Linear(d, 1); self.head_rul = nn.Linear(d, 1)
        self.head_ae = AEToxicHead(d, d_in, n_ts); self.head_mdn = MDNToxicHead(d, k_mdn)

    def encode_seq(self, x):                  # (B,T,D_in)->(B,T,d)
        h = F.silu(self.proj(x))
        if self.ts is not None: h = self.ts(h)
        if self.gd is not None: h = self.gd(h)
        return self.norm(h)

    def embed(self, x):
        return self.encode_seq(x).mean(dim=1)  # (B,d)

    def forward(self, x):
        z = self.embed(x)
        soh = self.head_soh(z).squeeze(-1); rul = self.head_rul(z).squeeze(-1)
        return soh, rul, self.head_ae(z), self.head_mdn(z)


# =============================================================================
#  MTG tri-weighting
# =============================================================================
def tri_weights(rate, temp, dsoh, gamma=1.0, rate_hi=None, temp_lo=None, temp_hi=None,
                terms=("rate", "temp", "degrad")):
    """Multiplicative tri-weight gate w = w_rate * w_temp * w_degrad.

    Thresholds are DATA-DRIVEN (quantiles of the current dataset) by default, so
    the fast-charge and extreme-temperature windows remain meaningful even when a
    dataset is concentrated at high C-rate (MATR: 99.8% >= 3.6 C).  A fixed 1.5 C
    cut would label almost every MATR sample 'fast-charge' and erase the
    per-condition contrast this gate is meant to create.

    rate_hi : fast-charge threshold (default: dataset 70th percentile of c_rate)
    temp_lo/temp_hi : extreme-temperature band (default: 10th/90th percentile)
    """
    rate = np.asarray(rate, np.float32)
    temp = np.asarray(temp, np.float32)
    note = []
    # --- degenerate-quantile guard (single-protocol datasets like HUST) ---
    rate_spread = float(rate.max() - rate.min()) if rate.size else 0.0
    rate_uniform = rate_spread < 1e-6
    if rate_hi is None:
        if rate_uniform:
            # every sample shares one C-rate: keep the whole set as 'fast-charge'
            # when that shared rate is physically high (>= 2C), else drop the term.
            if float(rate.max()) >= 2.0:
                rate_hi = float(rate.max()) - 1e-3
                note.append('rate uniform %.2fC -> all fast-charge' % rate.max())
            else:
                rate_hi = float('inf')
                note.append('rate uniform %.2fC < 2C -> gate disabled' % rate.max())
        else:
            rate_hi = float(np.quantile(rate, 0.70))
    temp_spread = float(temp.max() - temp.min()) if temp.size else 0.0
    if temp_lo is None or temp_hi is None:
        if temp_spread < 1.0:
            temp_lo, temp_hi = -float('inf'), float('inf')
            note.append('temp uniform -> gate disabled')
        else:
            temp_lo = float(np.quantile(temp, 0.10))
            temp_hi = float(np.quantile(temp, 0.90))
    wr = np.where(rate > rate_hi, 1.0 + gamma, 1.0).astype(np.float32) if "rate" in terms \
        else np.ones_like(rate, np.float32)
    wt = np.where((temp < temp_lo) | (temp > temp_hi), 1.0 + gamma, 1.0).astype(np.float32) if "temp" in terms \
        else np.ones_like(temp, np.float32)
    md = np.maximum(np.abs(dsoh).max(), 1e-8)
    wd = (1.0 + gamma * (np.abs(dsoh) / md).astype(np.float32)) if "degrad" in terms \
        else np.ones_like(rate, np.float32)
    return wr * wt * wd, dict(rate_hi=rate_hi, temp_lo=temp_lo, temp_hi=temp_hi,
                              terms=list(terms), notes=note)


# =============================================================================
#  Dataset & collate
# =============================================================================
FEATS = ("voltage", "current", "temperature", "resistance")

def _norm(a, lo, hi):
    a = np.asarray(a, np.float32)
    return np.clip((a - lo) / max(hi - lo, 1e-6), 0.0, 1.0)


def build_dataset(cycles, max_ts=128, gamma_w=1.0, w_terms=("rate", "temp", "degrad")):
    """cycles: list of dicts. Returns
    (X, S_norm, R_norm, W, cids, S_scale, R_scale).
    Features are globally min-max normalised per channel; both targets are
    normalised to [0,1] so the two primary-task gradients stay balanced and the
    toxic aux heads can drive collapse; the caller maps back to physical units."""
    cycles = [c for c in cycles if c.get("SOH", 0) > 0]   # drop missing-capacity rows
    rate = np.array([c["C_rate"] for c in cycles], np.float32)
    temp = np.array([c["temp"] for c in cycles], np.float32)
    dsoh = np.array([c["dSOH"] for c in cycles], np.float32)
    w, thr = tri_weights(rate, temp, dsoh, gamma_w, terms=w_terms)
    # Condition groups from data-driven thresholds.  0=standard (rate<=thr, temp in-band),
    # 1=fast-charge (rate>thr), 2=extreme-temperature (temp out of band, not fast).
    # Priority: extreme-temp takes 2 only when not already fast-charge, so the two
    # hardest-condition groups are disjoint and each is non-empty by construction.
    cond = np.where(
        rate > thr["rate_hi"], 1,
        np.where((temp < thr["temp_lo"]) | (temp > thr["temp_hi"]), 2, 0)
    ).astype(np.int64)
    _cond_counts = {int(g): int((cond == g).sum()) for g in (0, 1, 2)}
    X = np.zeros((len(cycles), max_ts, len(FEATS)), np.float32)
    SOH = np.array([c["SOH"] for c in cycles], np.float32)      # 0-100 %
    RUL = np.array([c["RUL"] for c in cycles], np.float32)      # cycles
    # CENS_AWARE_V3: right-censoring mask (1 = RUL is a lower bound)
    CENS = np.array([int(c.get("cens", 0)) for c in cycles], np.int64)
    cids = np.array([c.get("_cid", "cell") for c in cycles])
    rul_max = max(float(RUL.max()), 1.0)
    S_n = SOH / 100.0
    R_n = RUL / rul_max
    # per-channel global min/max for normalisation
    for j, f in enumerate(FEATS):
        lo, hi = float("inf"), float("-inf")
        for c in cycles:
            v = np.asarray(c.get(f, np.zeros(0)), np.float32)
            if v.size:
                lo = min(lo, float(v.min()))
                hi = max(hi, float(v.max()))
        for i, c in enumerate(cycles):
            v = np.asarray(c.get(f, np.zeros(0)), np.float32)
            v = _norm(v, lo, hi)
            if len(v) > max_ts: v = v[-max_ts:]
            elif len(v) < max_ts: v = np.concatenate([np.zeros(max_ts - len(v)), v])
            X[i, :, j] = v
    return X, S_n, R_n, w, cond, cids, (100.0, rul_max), thr, _cond_counts, CENS


class CycDataset(Dataset):
    def __init__(self, X, SOH, RUL, W, Cond, Cens=None):
        self.X, self.S, self.R, self.W, self.C = X, SOH, RUL, W, Cond
        self.Cn = (np.zeros(len(X), np.int64) if Cens is None else Cens)
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        return (torch.tensor(self.X[i]), torch.tensor(self.S[i]),
                torch.tensor(float(self.R[i])), torch.tensor(self.W[i]),
                torch.tensor(int(self.C[i])), torch.tensor(int(self.Cn[i])))


def collate(b):
    xs, ss, rs, ws, cs, cns = zip(*b)
    return (torch.stack(xs), torch.stack(ss), torch.stack(rs), torch.stack(ws),
            torch.stack(cs), torch.stack(cns))


# =============================================================================
#  Train / eval
# =============================================================================
# ---------------------------------------------------------------- AGG_SWITCH_V3
def _agg_sum(gp, ga, alpha, ema):
    out = []
    for p, a in zip(gp, ga):
        if p is None and a is None:
            out.append(None)
        elif p is None:
            out.append(alpha * a)
        elif a is None:
            out.append(p)
        else:
            out.append(p + alpha * a)
    return out


def _agg_pcgrad(gp, ga, alpha, ema):
    """PCGrad: if the aux gradient conflicts with the primary, project it off."""
    out = []
    for p, a in zip(gp, ga):
        if p is None or a is None:
            out.append(p if p is not None else (a * alpha if a is not None else None))
            continue
        pv, av = p.reshape(-1), a.reshape(-1)
        dot = float(pv @ av)
        if dot < 0:
            a = (a.reshape(-1) - dot / float(pv @ pv + 1e-12) * pv).reshape(a.shape)
        out.append(p + alpha * a)
    return out


def _agg_famo(gp, ga, alpha, ema):
    """FAMO-style adaptive scalarisation: rescale the aux gradient by the
    running ratio of the two losses."""
    lp = float(ema.get('lp', 1.0)); la = float(ema.get('la', 1.0))
    w = alpha * lp / max(la, 1e-12)
    w = min(w, 1e6)
    return [((p if p is not None else 0) + w * (a if a is not None else 0)
             if (p is not None or a is not None) else None) for p, a in zip(gp, ga)]


def _agg_cagrad(gp, ga, alpha, ema, c=0.6):
    """CAGrad intuition: keep the primary from regressing inside a norm ball
    while merging the aux direction."""
    out = []
    for p, a in zip(gp, ga):
        if p is None or a is None:
            out.append(p if p is not None else (a * alpha if a is not None else None))
            continue
        pv = p.reshape(-1)
        s = (p + alpha * a).reshape(-1)
        pn2 = float(pv @ pv) + 1e-12
        sn2 = float(s @ s) + 1e-12
        lam = max(0.0, (c * pn2 - float(pv @ s)) / sn2)
        out.append((s + lam * s).reshape(p.shape))
    return out


def _agg_detach(gp, ga, alpha, ema):
    """STF-0 boundary: aux gradient never reaches the shared encoder."""
    return [(p if p is not None else None) for p in gp]


_AGG = {"sum": _agg_sum, "pcgrad": _agg_pcgrad, "famo": _agg_famo,
        "cagrad": _agg_cagrad, "detach": _agg_detach}


def _grads_of(model, loss, retain=False):
    """Parameter gradients of `loss` via autograd.grad (no .grad round-trip).

    Equivalent to zero_grad + backward + collect, but avoids materialising and
    cloning every parameter's .grad tensor; that double copy dominated runtime
    on the 16k-sample MATR split.  allow_unused=True is required because the
    detached auxiliary path legitimately contributes no gradient to the shared
    encoder, so some entries come back None."""
    params = [p for p in model.parameters() if p.requires_grad]
    grads = torch.autograd.grad(loss, params, retain_graph=retain,
                                allow_unused=True)
    return list(grads)


def _write_grads(model, grads):
    params = [p for p in model.parameters() if p.requires_grad]
    for p in params:
        p.grad = None
    for p, g in zip(params, grads):
        if g is not None:
            p.grad = g.detach().clone()


def run(model, dl_tr, dl_te, opt, epochs, dev, alpha_aux, stf, wattr, wgt, scale,
        tox_var=False, single=False, cens_aware=True,
        agg='sum', ema=None, amp=True):   # AGG_SWITCH_V3 + AMP_BF16_V3
    """single: 'soh'/'rul' -> train only that head (single-task ceiling, no aux).
    Returns best {soh_rmse_%, rul_mae_cycles} in physical units."""
    s_scale, r_scale = scale
    best = {"soh": float("inf"), "rul": float("inf")}
    for ep in range(1, epochs+1):
        model.train(); tot = 0.0; nt = 0
        for xb, sb, rb, wb, _, cnb in dl_tr:
            xb, sb, rb, wb = xb.to(dev), sb.to(dev), rb.to(dev), wb.to(dev)
            cnb = cnb.to(dev)
            opt.zero_grad()
            _amp = torch.autocast('cuda', dtype=torch.bfloat16, enabled=(amp and dev == 'cuda'))
            _amp.__enter__()
            z = model.embed(xb)
            soh = model.head_soh(z).squeeze(-1); rul = model.head_rul(z).squeeze(-1)
            l_soh = F.mse_loss(soh, sb, reduction='none')
            # censored-aware RUL loss: exact L1 for observed EOL, one-sided hinge
            # (penalise only under-prediction) for right-censored lower bounds.
            l_rul_exact = F.l1_loss(rul, rb, reduction='none')
            l_rul_cens = F.relu(rb - rul)          # zero when pred >= lower bound
            if cens_aware:
                l_rul = torch.where(cnb > 0, l_rul_cens, l_rul_exact)
            else:
                l_rul = l_rul_exact
            # weight multiplication on the primary task(s) only
            w = wb if wattr else torch.ones_like(wb)
            if single == "soh":
                prim = l_soh * w
            elif single == "rul":
                prim = l_rul * w
            else:
                prim = (l_soh + l_rul) * w
            if single:
                loss = prim.mean()
            elif tox_var:
                # pure variance-shrinkage: pulls every rep toward the batch mean,
                # i.e. along the exact theoretical collapse direction u_c = h-E_b[h].
                aux_src = z.detach() if stf else z          # z:(B,d)
                mu = aux_src.mean(0, keepdim=True)
                L_aux = ((aux_src - mu) ** 2).mean(dim=1)   # per-sample batch variance
                aux = L_aux
            elif stf:
                zt = z.detach()
                l_ae = F.mse_loss(model.head_ae(zt), xb, reduction='none').mean(dim=(1, 2))
                pi, mu, sig = model.head_mdn(zt)
                l_mdn = MDNToxicHead.nll(pi, mu, sig, rb)
                aux = l_ae + l_mdn
            else:
                recon = model.head_ae(z)
                l_ae = F.mse_loss(recon, xb, reduction='none').mean(dim=(1, 2))
                pi, mu, sig = model.head_mdn(z)
                l_mdn = MDNToxicHead.nll(pi, mu, sig, rb)
                aux = l_ae + l_mdn
            if not single:
                # AGG_SWITCH_V3: the conflict-resolution operators only make
                # sense on the toxicity-EXPOSED path.  Under stf / tox_var the
                # auxiliary gradient is already detached from the encoder, so
                # the cheap single-backward path is numerically identical.
                if agg == 'sum' or stf or tox_var:
                    loss = prim.mean() + alpha_aux * aux.mean()
                    loss.backward(); opt.step()
                else:
                    # AGG_SWITCH_V3: separate the two gradient sources and merge
                    # them with the chosen conflict-resolution operator.  The
                    # theory predicts none of pcgrad/famo/cagrad can stop
                    # toxicity because the toxic gradient is aligned, not opposed.
                    lp = prim.mean(); la = aux.mean()
                    if ema is not None:
                        ema['lp'] = 0.9 * ema.get('lp', float(lp)) + 0.1 * float(lp)
                        ema['la'] = 0.9 * ema.get('la', float(la)) + 0.1 * float(la)
                    gp = _grads_of(model, lp, retain=True)
                    ga = _grads_of(model, la, retain=False)
                    _write_grads(model, _AGG[agg](gp, ga, alpha_aux, ema or {}))
                    opt.step()
                    loss = lp.detach() + alpha_aux * la.detach()   # reporting only
            else:
                loss.backward(); opt.step()
            _amp.__exit__(None, None, None)
            tot += float(loss.item() if hasattr(loss, 'item') else loss) * xb.shape[0]
            nt += xb.shape[0]
        # eval (overall + per-condition)
        model.eval()
        with torch.no_grad():
            mse_s = 0.0; mae_r = 0.0; nb = 0
            acc = {g: [0.0, 0.0, 0] for g in (0, 1, 2)}   # g -> [mse, mae, n]
            for xb, sb, rb, _, cb, _cn in dl_te:
                xb, sb, rb, cb = xb.to(dev), sb.to(dev), rb.to(dev), cb.to(dev)
                soh, rul, _, _ = model(xb)
                mse_s += F.mse_loss(soh, sb).item() * xb.shape[0]
                mae_r += F.l1_loss(rul, rb).item() * xb.shape[0]
                nb += xb.shape[0]
                for g in (0, 1, 2):
                    m = cb == g
                    if m.any():
                        acc[g][0] += F.mse_loss(soh[m], sb[m]).item() * m.sum().item()
                        acc[g][1] += F.l1_loss(rul[m], rb[m]).item() * m.sum().item()
                        acc[g][2] += m.sum().item()
            rmse_pct = math.sqrt(mse_s / nb) * s_scale   # SOH RMSE in %
            mae_cyc = (mae_r / nb) * r_scale             # RUL MAE in cycles
            per_cond = {str(g): dict(soh=(math.sqrt(acc[g][0] / acc[g][2]) * s_scale
                                            if acc[g][2] else None),
                                     rul=(acc[g][1] / acc[g][2] * r_scale
                                          if acc[g][2] else None),
                                     n=acc[g][2]) for g in (0, 1, 2)}
        if rmse_pct < best["soh"]:
            best = dict(soh=rmse_pct, rul=mae_cyc, scatter=rep_scatter(model, dl_te, dev),
                        per_cond=per_cond)
            torch.save(model.state_dict(), f"/tmp/_bmtl_best_{id(model)}.pt")
    # load best weights for final scatter
    bf = f"/tmp/_bmtl_best_{id(model)}.pt"
    if os.path.exists(bf):
        model.load_state_dict(torch.load(bf, map_location=dev))
        best["scatter"] = rep_scatter(model, dl_te, dev)
        os.remove(bf)
    return best


@torch.no_grad()
def rep_scatter(model, dl, dev):
    model.eval(); sc = []
    for xb, *_ in dl:   # collate yields (x, s, r, w, cond, cens)
        z = model.embed(xb.to(dev))
        sc.append(float(z.var(dim=1).mean().item()))
    return float(np.mean(sc))


def _path(*parts):
    root = os.environ.get("REPFIX_DATA_X",
                          os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "data_x"))
    return os.path.join(root, *parts)


def _load_hust_npz():
    """Load the HUST npz cache and expand to the list-of-dicts schema used by
    build_dataset (arrays are float16 on disk, cast to float32 on read)."""
    p = _path("battery_parsed", "hust_cycles.npz")
    if not os.path.exists(p):
        print(f"ERROR: HUST cache not found at {p}\nRun _build_hust_npz.py first.")
        sys.exit(1)
    d = np.load(p, allow_pickle=False)
    X = d["X"].astype(np.float32)
    SOH = d["SOH"].astype(np.float32)
    RUL = d["RUL"]
    CR = d["C_rate"].astype(np.float32)
    TP = d["temp"].astype(np.float32)
    DS = d["dSOH"].astype(np.float32)
    CID = d["cell_id"]
    out = []
    for i in range(len(SOH)):
        out.append(dict(
            voltage=X[i, :, 0].copy(), current=X[i, :, 1].copy(),
            temperature=X[i, :, 2].copy(), resistance=X[i, :, 3].copy(),
            SOH=float(SOH[i]), RUL=int(RUL[i]), C_rate=float(CR[i]),
            temp=float(TP[i]), dSOH=float(DS[i]), _cid=str(CID[i])))
    print(f"  HUST: loaded {len(out)} samples from {p}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="CALCE", choices=["CALCE", "MATR", "NASA", "HUST"])
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--max-ts", type=int, default=128)
    ap.add_argument("--alpha-aux", type=float, default=1.0)
    ap.add_argument("--gamma", type=float, default=1.0)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--seeds", default="0,1,2,3")
    ap.add_argument("--seed-cell", type=int, default=0)
    ap.add_argument("--no-tsmixer", action="store_true")
    ap.add_argument("--no-gatedelta", action="store_true")
    ap.add_argument("--tox-var", action="store_true",
                    help="theory-consistent variance-shrinkage toxifier (u_c=h-E[h]) "
                         "instead of AE+MDN distributed heads")
    ap.add_argument("--single-only", action="store_true",
                    help="train only single-task SOH/RUL health ceilings (no MT configs)")
    ap.add_argument("--eol-only", action="store_true",
                    help="keep only cells that genuinely reached EOL (min SOH <= 80%%); "
                         "removes right-censored RUL labels (P2 fix)")
    ap.add_argument("--eol-thresh", type=float, default=80.0,
                    help="SOH %% threshold defining end-of-life (default 80)")
    ap.add_argument("--drop-fresh", action="store_true",
                    help="drop windows with SOH >= 99.9%% (unaged, label-poor)")
    ap.add_argument("--w-terms", default="rate,temp,degrad",
                    help="comma list of tri-weight terms to activate (ablation)")
    ap.add_argument("--amp", dest="amp", action="store_true", default=True,
                    help="bf16 autocast training (evaluation always fp32)")
    ap.add_argument("--no-amp", dest="amp", action="store_false")
    ap.add_argument("--cens-aware", dest="cens_aware", action="store_true", default=True,
                    help="CENS_AWARE_V3_S2: use Tobit-style one-sided loss on right-censored RUL")
    ap.add_argument("--no-cens-aware", dest="cens_aware", action="store_false",
                    help="legacy behaviour: treat censored RUL lower bounds as exact labels")
    ap.add_argument("--agg", default="sum",
                    choices=["sum", "pcgrad", "famo", "cagrad", "detach"],
                    help="AGG_SWITCH_V3: gradient aggregation / conflict-resolution operator")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    enable_max_perf()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if a.dataset == "HUST":
        cycles = _load_hust_npz()
    else:
        p = _path("battery_parsed", f"{a.dataset.lower()}_cycles.json")
        if not os.path.exists(p):
            print(f"ERROR: parsed data not found at {p}\nRun battery_preprocess.py first.")
            sys.exit(1)
        with open(p) as f:
            cycles = json.load(f)
    # ---- P2 fix: EOL-aware filtering of right-censored RUL labels ----
    if a.eol_only or a.drop_fresh:
        from collections import defaultdict as _dd
        _by = _dd(list)
        for c in cycles:
            _by[c.get("_cid", "cell")].append(c)
        kept_cells, dropped_cells = [], []
        for cid, cs in _by.items():
            mins = min(float(x.get("SOH", 100.0)) for x in cs)
            if a.eol_only and mins > a.eol_thresh:
                dropped_cells.append(cid)
            else:
                kept_cells.append(cid)
        keep = set(kept_cells)
        nel = sum(1 for cid, cs in _by.items()
                  if min(float(x.get("SOH", 100.0)) for x in cs) <= a.eol_thresh)
        cycles = [c for c in cycles if c.get("_cid", "cell") in keep]
        if a.drop_fresh:
            cycles = [c for c in cycles if float(c.get("SOH", 0.0)) < 99.9]
        print("  [eol] cells kept=%d dropped=%d (reached EOL=%d/%d) samples=%d"
              % (len(kept_cells), len(dropped_cells), nel, len(_by), len(cycles)))
    _wterms = tuple(x.strip() for x in a.w_terms.split(",") if x.strip())
    X, S, R, W, C, cids, scale, thr, cond_counts, CENS = build_dataset(
        cycles, a.max_ts, a.gamma, w_terms=_wterms)
    print("  tri-weight thresholds:", thr, " overall cond counts:", cond_counts)
    # leave-cell-out split: partition unique cells, keep 85% of cells in train
    uniq = sorted(set(cids.tolist()))
    random.Random(a.seed_cell).shuffle(uniq)
    tr_cells = set(uniq[:max(1, int(0.85 * len(uniq)))])
    tr_mask = np.isin(cids, list(tr_cells))
    te_mask = ~tr_mask
    Xtr, Str, Rtr, Wtr, Ctr = X[tr_mask], S[tr_mask], R[tr_mask], W[tr_mask], C[tr_mask]
    Xte, Ste, Rte, Wte, Cte = X[te_mask], S[te_mask], R[te_mask], W[te_mask], C[te_mask]
    Cntr, Cnte = CENS[tr_mask], CENS[te_mask]
    print(f"  cells train={len(tr_cells)} test={len(uniq)-len(tr_cells)} "
          f"samples train={Xtr.shape[0]} test={Xte.shape[0]}")
    dl_tr = DataLoader(CycDataset(Xtr, Str, Rtr, Wtr, Ctr, Cntr), batch_size=a.batch, shuffle=True, collate_fn=collate)
    dl_te = DataLoader(CycDataset(Xte, Ste, Rte, Wte, Cte, Cnte), batch_size=a.batch, shuffle=False, collate_fn=collate)
    _nc = int(CENS.sum())
    print("  censoring: %d/%d samples right-censored (%.1f%%) -- cens_aware=%s"
          % (_nc, len(CENS), 100.0 * _nc / max(len(CENS), 1), a.cens_aware))

    configs = [("joint", False, 0), ("joint_w", False, 1),
               ("stf0", True, 0), ("stf0_w", True, 1)]   # ours = stf0_w
    seeds = [int(x) for x in a.seeds.split(",")]
    rows = []
    # single-task health ceilings (SOH-only, RUL-only) -- no auxiliary loss
    if not a.single_only:
        st_ceiling = {}
        for tk in ("soh", "rul"):
            per = []
            for sd in seeds:
                set_seed(sd)
                m = BMTL(d_in=len(FEATS), d=a.d, n_ts=a.max_ts,
                         use_tsmixer=not a.no_tsmixer, use_gatedelta=not a.no_gatedelta).to(dev)
                opt = torch.optim.Adam(m.parameters(), lr=a.lr)
                per.append(run(m, dl_tr, dl_te, opt, a.epochs, dev, a.alpha_aux,
                               False, 0, a.gamma, scale, single=tk,
                               cens_aware=a.cens_aware, amp=a.amp))
            st_ceiling[tk] = dict(
                rmse_soh=float(np.mean([r["soh"] for r in per])),
                mae_rul=float(np.mean([r["rul"] for r in per])),
                scatter=float(np.mean([r["scatter"] for r in per])))
            print(f"single[{tk}]", st_ceiling[tk])
    else:
        st_ceiling = {}
    for cname, stf, wattr in configs:
        per_seed = []
        for sd in seeds:
            set_seed(sd)
            m = BMTL(d_in=len(FEATS), d=a.d, n_ts=a.max_ts,
                     use_tsmixer=not a.no_tsmixer, use_gatedelta=not a.no_gatedelta).to(dev)
            opt = torch.optim.Adam(m.parameters(), lr=a.lr)
            b = run(m, dl_tr, dl_te, opt, a.epochs, dev, a.alpha_aux, stf, wattr, a.gamma,
                    scale, tox_var=a.tox_var, cens_aware=a.cens_aware,
                    agg=a.agg, ema={}, amp=a.amp)
            per_seed.append(dict(**b, seed=sd))
        rows.append(dict(config=cname,
                         rmse_soh=float(np.mean([r["soh"] for r in per_seed])),
                         rmse_soh_std=float(np.std([r["soh"] for r in per_seed])),
                         mae_rul=float(np.mean([r["rul"] for r in per_seed])),
                         scatter=float(np.mean([r["scatter"] for r in per_seed])),
                         per_cond={g: dict(
                             soh=float(np.nanmean([r["per_cond"][g]["soh"]
                                                   for r in per_seed
                                                   if r["per_cond"][g]["soh"] is not None])),
                             rul=float(np.nanmean([r["per_cond"][g]["rul"]
                                                   for r in per_seed
                                                   if r["per_cond"][g]["rul"] is not None])),
                             n=int(np.sum([r["per_cond"][g]["n"] for r in per_seed])))
                                   for g in ("0", "1", "2")}))
        print(cname, rows[-1])

    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w") as f:
        json.dump(dict(dataset=a.dataset, d=a.d, gamma=a.gamma, alpha_aux=a.alpha_aux,
                       tox_var=a.tox_var, agg=a.agg, seeds=seeds,
                       eol_only=a.eol_only, drop_fresh=a.drop_fresh, w_terms=list(_wterms),
                       eol_thresh=a.eol_thresh,
                       tri_weight_thresholds=thr, cond_counts=cond_counts,
                       single_ceiling=st_ceiling, results=rows), f, indent=2)
    print("wrote", a.out)


if __name__ == "__main__":
    main()