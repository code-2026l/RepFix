"""Verify a pristine supplementary release; run optional checks in a temporary copy.

The default path uses only Python's standard library. It checks files and recorded
provenance, not predictions from tensor checkpoints excluded from this archive.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
TESTS = [
    'test_consumer_risk.py', 'test_readout_alignment.py',
    'test_scale_boundaries.py', 'test_readout_nullspace.py',
    'test_compiled_readout.py', 'test_nonlinear_interface.py',
    'test_nonlinear_selection.py',
    'test_affine_chart.py', 'test_vision_chart.py',
    'test_legacy_head_fit.py',
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_path(root, name):
    path = PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or ':' in name or '\\' in name:
        raise ValueError('Unsafe manifest path: ' + name)
    target = root.joinpath(*path.parts)
    if target.is_symlink() or not target.resolve().is_relative_to(root.resolve()):
        raise ValueError('Payload path leaves the artifact: ' + name)
    return target


def verify_files(root):
    manifest = json.loads((root / 'ARTIFACT_MANIFEST.json').read_text(encoding='utf-8'))
    files = manifest['sha256']
    if not files:
        raise ValueError('Empty artifact manifest')
    for name, expected in files.items():
        path = payload_path(root, name)
        if not path.is_file() or digest(path) != expected:
            raise ValueError('Missing or changed payload: ' + name)
    inputs, figures, seen = [], [], set()
    def inspect_tex(name):
        if name in seen:
            return
        seen.add(name)
        tex = payload_path(root, 'paper/' + name).read_text(encoding='utf-8')
        children = re.findall(r'\\input\{([^}]+)\}', tex)
        figures.extend(re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}', tex))
        for child in children:
            inputs.append(child)
            inspect_tex(child)
    inspect_tex('RepFix_ICLR2027.tex')
    for name in inputs + figures:
        if 'paper/' + name not in files:
            raise ValueError('Unmanifested manuscript input: ' + name)
    if len(figures) != manifest['publication_figures']:
        raise ValueError('Included manuscript figures differ from the release manifest')
    if manifest['pdf_sha256'] != digest(root / 'paper/RepFix_ICLR2027.pdf'):
        raise ValueError('The manuscript PDF does not match the manifest')

    sources = plans = records = versioned_sources = repr_sources = 0
    python_hashes = {value for name, value in files.items() if name.endswith('.py')}
    # Some historical vision replay records called state_hash(bytes), which
    # hashes repr(bytes). Preserve that convention and the exact source bytes.
    legacy_repr_names = {'vision_scale_replay.py', 'vision_boundary_cpu.py'}
    for name in files:
        if PurePosixPath(name).name in legacy_repr_names:
            python_hashes.add(hashlib.sha256(repr((root/name).read_bytes()).encode()).hexdigest())
    plan_hashes = {value for name, value in files.items()
                   if name.startswith('docs/plans/') and name.endswith('.md')}
    base = 'repro/results/CPUCONT/'
    for name in sorted(files):
        if not name.startswith(base) or not name.endswith('.json'):
            continue
        row = json.loads((root / name).read_text(encoding='utf-8'))
        if not isinstance(row, dict):
            continue
        if row.get('complete'):
            records += 1
        source_map = row.get('source_sha256', {})
        if isinstance(source_map, str):
            if source_map not in python_hashes:
                raise ValueError('Recorded driver digest is unavailable: ' + name)
            sources += 1
            source_map = {}
        for field, expected in row.items():
            if field.endswith('_source_sha256') and isinstance(expected, str):
                if expected not in python_hashes:
                    raise ValueError('Recorded source digest is unavailable: ' + name + '/' + field)
                sources += 1
        for source, expected in source_map.items():
            if not isinstance(expected, str) or len(expected) != 64:
                continue
            path = payload_path(root, source)
            if not path.is_file():
                path = payload_path(root, 'repro/scripts/' + source)
            candidates=[path,payload_path(root,'repro/source_versions/'+expected+'/'+PurePosixPath(source).name)]
            matched=None
            for candidate in candidates:
                if not candidate.is_file():continue
                if digest(candidate)==expected:
                    matched=candidate
                    break
                if candidate.name in legacy_repr_names and hashlib.sha256(repr(candidate.read_bytes()).encode()).hexdigest()==expected:
                    matched=candidate
                    repr_sources+=1
                    break
            if matched is None:
                raise ValueError('Recorded source mismatch in ' + name + ': ' + source)
            versioned_sources+=matched!=path
            sources += 1
        for field,expected in row.items():
            if field.endswith('plan_sha256') and isinstance(expected,str):
                if expected not in plan_hashes:
                    raise ValueError('Recorded plan unavailable: '+name+'/'+field)
                plans+=1
        if isinstance(row.get('source'),dict) and 'script_sha256' in row['source']:
            if row['source']['script_sha256'] not in python_hashes:
                raise ValueError('Nested recorded script unavailable: '+name)
            sources+=1

    choice = json.loads((root / base / 'nonlinear_development_choice.json').read_text(encoding='utf-8'))
    if any(v['confirm'] for v in choice['selected'].values()):
        raise ValueError('The nonlinear decision differs from the released failed gate')
    development = [name for name in files if re.fullmatch(base + r'nonlinear_development/b\d{3}\.json', name)]
    if len(development) != 6 or any(name.startswith(base + 'nonlinear_confirmation/') for name in files):
        raise ValueError('Unexpected nonlinear development/confirmation family')
    for name in development:
        row = json.loads((root / name).read_text(encoding='utf-8'))
        if row['splits']['test_metrics_computed'] or any('test' in b for b in row['branches']):
            raise ValueError('Development record contains test outcomes: ' + name)

    chart_dev = [name for name in files if re.fullmatch(base+r'chart_development/a\d{3}\.json', name)]
    chart_confirm = [name for name in files if re.fullmatch(base+r'chart_confirmation/c\d{3}\.json', name)]
    chart_replay = [name for name in files if re.fullmatch(base+r'chart_replay/e\d{3}\.json', name)]
    if len(chart_dev)!=6 or len(chart_confirm)!=10 or len(chart_replay)!=10:
        raise ValueError('The fixed chart evidence family is incomplete')
    selection_name=base+'chart_development_choice.json'
    selection=json.loads((root/selection_name).read_text())
    if selection['tasks']['har']['confirm'] or selection['tasks']['radioml']['selected']!='paired_ridge':
        raise ValueError('The frozen chart choice changed')
    for name in chart_confirm:
        row=json.loads((root/name).read_text())
        if row['selection_sha256']!=digest(root/selection_name):
            raise ValueError('Confirmation choice hash differs: '+name)
    for name in chart_dev:
        row=json.loads((root/name).read_text())
        if row['splits']['test_metrics_computed']:
            raise ValueError('Chart development opened test outcomes')
    chart_summary=json.loads((root/base/'chart_confirmation_summary.json').read_text())
    if chart_summary['tasks']['radioml']['passes'] or chart_summary['tasks']['radioml']['metrics']['certified']!=0:
        raise ValueError('The failed chart compatibility criterion was changed')

    protected_original = [name for name in files if re.fullmatch(base+r'protected_head/ph_(?:har_)?conf_30\d\.json', name)]
    protected_audits = [name for name in files if re.fullmatch(base+r'protected_head_audit/r\d{3}\.json', name)]
    protected_replays = [name for name in files if re.fullmatch(base+r'protected_head_reader_replay/v\d{3}\.json', name)]
    if any(len(family)!=20 for family in [protected_original,protected_audits,protected_replays]):
        raise ValueError('The protected-head audit family is incomplete')
    original_hashes={digest(root/name) for name in protected_original}
    audit_hashes={digest(root/name) for name in protected_audits}
    for name in protected_audits:
        row=json.loads((root/name).read_text())
        if not row['complete'] or row['original_record_sha256'] not in original_hashes or row['maximum_original_metric_error']!=0:
            raise ValueError('Original protected-head replay changed: '+name)
        if row['new_family_size']!=140 or not row['no_encoder_updates'] or row['labels_used_for_fitting']:
            raise ValueError('Fixed retrospective fit protocol changed: '+name)
    for name in protected_replays:
        row=json.loads((root/name).read_text())
        if (not row['complete'] or row['audit_sha256'] not in audit_hashes or
                len(row['branches'])!=7 or row['maximum_metric_error']!=0 or
                row['maximum_stationarity_residual']>1e-6 or row['refitting_performed']):
            raise ValueError('Frozen reader verification changed: '+name)
    protected_summary=json.loads((root/base/'protected_head_audit_summary.json').read_text())
    if protected_summary['original_gate_replaced']:
        raise ValueError('Retrospective results replaced original decisions')
    for domain,original_count,ols_count in [('har',9,10),('radioml',0,0)]:
        row=protected_summary['domains'][domain]
        if row['original']['passes'] or row['original']['certified']!=original_count or row['frozen_controls']['protected_ols']['certified']!=ols_count:
            raise ValueError('Protected-head verdict changed: '+domain)

    return manifest, dict(payload_files=len(files), manuscript_figures=len(figures),
        numerical_inputs=len(inputs), completed_cpu_records=records,
        recorded_source_hashes_checked=sources, recorded_plan_hashes_checked=plans,
        historical_source_versions_checked=versioned_sources,
        historical_repr_bytes_digests_checked=repr_sources,
        recorded_protected_original_replays_checked=60,recorded_protected_control_replays_checked=140,
        nonlinear_development_records=len(development), nonlinear_confirmation_tasks=0,
        manuscript_pdf_sha256=manifest['pdf_sha256'])


def execute(command, root):
    env = dict(os.environ)
    env.update(CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               OPENBLAS_NUM_THREADS='1', PYTHONUTF8='1')
    start = time.perf_counter()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', timeout=300)
    if result.returncode:
        raise RuntimeError('Check failed: ' + ' '.join(command[1:]) + '\n' +
                           result.stdout[-4000:] + '\n' + result.stderr[-2000:])
    return result.stdout, round(time.perf_counter() - start, 3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tests', action='store_true', help='Run 55 structural checks on CPU')
    parser.add_argument('--figures', action='store_true', help='Rebuild all included figures and compare numerical artists')
    parser.add_argument('--paper', action='store_true', help='Rebuild the manuscript and compare page text and pixels')
    args = parser.parse_args()
    manifest, report = verify_files(ROOT)
    report['checks'] = {}
    report['trained_tensor_states_replayed'] = False
    if not (args.tests or args.figures or args.paper):
        print(json.dumps(report, indent=2))
        return

    with tempfile.TemporaryDirectory(prefix='repfix-review-') as temporary:
        copy = Path(temporary)
        for name in manifest['sha256']:
            target = payload_path(copy, name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
        shutil.copyfile(ROOT / 'ARTIFACT_MANIFEST.json', copy / 'ARTIFACT_MANIFEST.json')
        if args.tests:
            print('Running structural checks on CPU...', flush=True)
            stdout, elapsed = execute([sys.executable, '-m', 'pytest'] +
                ['repro/scripts/' + name for name in TESTS] + ['-q'], copy)
            passed = re.search(r'(\d+) passed', stdout)
            if not passed or int(passed.group(1)) != 55:
                raise ValueError('Unexpected focused-test result: ' + stdout[-1000:])
            report['checks']['structural_tests'] = dict(passed=55, elapsed_seconds=elapsed)
        if args.figures:
            print('Rebuilding all included figures from recorded results...', flush=True)
            reference = json.loads((ROOT / 'paper/figures/publication_figure_manifest.json').read_text())
            _, elapsed = execute([sys.executable, 'repro/scripts/render_paper_figures.py'], copy)
            rebuilt = json.loads((copy / 'paper/figures/publication_figure_manifest.json').read_text())
            if set(reference['figures']) != set(rebuilt['figures']):
                raise ValueError('The figure set changed')
            for name, original in reference['figures'].items():
                for field in ['width_inches', 'height_inches', 'numerical_artists_sha256']:
                    if original[field] != rebuilt['figures'][name][field]:
                        raise ValueError('Figure evidence differs: ' + name + '/' + field)
            report['checks']['figures'] = dict(rebuilt=len(reference['figures']), matching_numerical_artists=len(reference['figures']),
                elapsed_seconds=elapsed)
        if args.paper:
            print('Building and comparing the manuscript...', flush=True)
            expected_pages=manifest['manuscript_snapshot']['total_pages']
            _, elapsed = execute([sys.executable, 'repro/scripts/build_cpu_paper.py'], copy)
            build = json.loads((copy / 'tmp/cpu_build/build_report.json').read_text())
            if build['warnings'] or build['main_text_pages'] != 9 or build['total_pages'] != expected_pages:
                raise ValueError('Unexpected manuscript build: ' + json.dumps(build))
            import fitz
            with fitz.open(ROOT / 'paper/RepFix_ICLR2027.pdf') as old, \
                    fitz.open(copy / 'paper/RepFix_ICLR2027.pdf') as new:
                if len(old) != len(new) or len(new) != expected_pages:
                    raise ValueError('Manuscript page count changed')
                text_matches = pixel_matches = 0
                for a, b in zip(old, new):
                    text_matches += a.get_text() == b.get_text()
                    pixel_matches += a.get_pixmap(alpha=False).samples == b.get_pixmap(alpha=False).samples
            if text_matches != expected_pages or pixel_matches != expected_pages:
                raise ValueError('Rendered manuscript differs: text %s, pixels %s of %s. '
                    'Check the LaTeX and figure font environment.' % (text_matches, pixel_matches,expected_pages))
            report['checks']['paper'] = dict(main_text_pages=9,total_pages=expected_pages,warnings=[],
                matching_page_text=text_matches,matching_page_pixels_at_72dpi=pixel_matches,elapsed_seconds=elapsed)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
